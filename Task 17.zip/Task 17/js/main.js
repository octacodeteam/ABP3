// js/main.js

/**
 * Orquestra a busca, implementando a limpeza da interface antes de exibir novos resultados.
 * Esta função atende diretamente ao requisito de usabilidade.
 */
async function realizarNovaBusca() {
    // 1. Identifica o elemento da interface onde os resultados são exibidos.
    const outputElement = document.getElementById('output');
    
    // 2. A LÓGICA DE LIMPEZA
    // Antes de fazer qualquer chamada à API, o conteúdo anterior é removido
    // e uma mensagem de feedback é exibida para o usuário.
    outputElement.textContent = 'Buscando novos dados...';

    // --- Simulação da Busca ---
    // As linhas abaixo chamam as funções do arquivo `api.js` (cujo código não está mostrado aqui).
    // Elas são responsáveis por buscar e processar os dados.
    const dadosBrutos = await buscarDadosStac(-23.3054, -45.9659, new Date().toISOString().split('T')[0], 180, ["S2-16D-2"]);
    const dadosProcessados = processarRespostaStac(dadosBrutos);
    
    // 3. Exibição do Novo Resultado
    // Após a conclusão da busca, o conteúdo é substituído novamente.
    if (dadosProcessados && dadosProcessados.length > 0) {
        outputElement.textContent = JSON.stringify(dadosProcessados, null, 2);
    } else {
        outputElement.textContent = 'Nenhum resultado encontrado.';
    }
}

/**
 * Ponto de entrada da aplicação: aguarda a página carregar
 * e conecta o botão à função de busca.
 */
document.addEventListener('DOMContentLoaded', () => {
    const searchButton = document.getElementById('searchButton');
    // Adiciona o "ouvinte" de eventos que dispara todo o processo.
    searchButton.addEventListener('click', realizarNovaBusca);
});